#include "../ref_gl/gl_local.h"

void		GLimp_BeginFrame( float camera_separation )
{
}

void		GLimp_EndFrame( void )
{
}

int 		GLimp_Init( void *hinstance, void *hWnd )
{
}

void		GLimp_Shutdown( void )
{
}

int     	GLimp_SetMode( int *pwidth, int *pheight, int mode, qboolean fullscreen )
{
}

void		GLimp_AppActivate( qboolean active )
{
}

void		GLimp_EnableLogging( qboolean enable )
{
}

void		GLimp_LogNewFrame( void )
{
}

