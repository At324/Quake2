int glob_match(char *pattern, char *text);
